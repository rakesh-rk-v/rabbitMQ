package com.uol.message.MessageConsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessageConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
