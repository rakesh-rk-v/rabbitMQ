package com.uol.message.MessagePublisher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessagePublisherApplication {

	public static void main(String[] args) {
		SpringApplication.run(MessagePublisherApplication.class, args);
	}

}
